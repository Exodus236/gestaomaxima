import { useState } from 'react';
import { BackgroundHearts } from './components/BackgroundHearts';
import { WelcomeScreen } from './components/WelcomeScreen';
import { QuestionScreen, StepType } from './components/QuestionScreen';
import { FinalScreen } from './components/FinalScreen';
import { SoundToggle } from './components/SoundToggle';

import { DlcWelcomeScreen } from './components/DlcWelcomeScreen';
import { AchievementsScreen } from './components/AchievementsScreen';
import { SecretAlbumScreen } from './components/SecretAlbumScreen';
import { DlcFinalScreen } from './components/DlcFinalScreen';

type Mode = 'dlc' | 'proposal';
type DlcScreenState = 'dlc-welcome' | 'dlc-achievements' | 'dlc-album' | 'dlc-final';
type ProposalScreenState = 'welcome' | 1 | 2 | 3 | 4 | 'final';

export default function App() {
  const [mode, setMode] = useState<Mode>('dlc');
  const [dlcScreen, setDlcScreen] = useState<DlcScreenState>('dlc-welcome');
  const [proposalScreen, setProposalScreen] = useState<ProposalScreenState>('welcome');

  // DLC Flow Handlers
  const handleDlcUnlock = () => setDlcScreen('dlc-achievements');
  const handleOpenDlcAlbum = () => setDlcScreen('dlc-album');
  const handleAlbumComplete = () => setDlcScreen('dlc-final');
  const handleDlcRestart = () => setDlcScreen('dlc-welcome');

  // Proposal Flow Handlers
  const handleProposalStart = () => setProposalScreen(1);
  const handleProposalNext = () => {
    if (proposalScreen === 1) setProposalScreen(2);
    else if (proposalScreen === 2) setProposalScreen(3);
    else if (proposalScreen === 3) setProposalScreen(4);
    else if (proposalScreen === 4) setProposalScreen('final');
  };
  const handleProposalRestart = () => setProposalScreen('welcome');

  return (
    <main className="relative w-full min-h-screen overflow-y-auto overflow-x-hidden flex flex-col items-center justify-between py-4 sm:py-6 px-2 bg-gradient-to-br from-rose-50 via-pink-100 to-rose-200 select-none">
      {/* Background Hearts */}
      <BackgroundHearts />

      {/* Top Header Controls: Mode Selector & Sound Toggle */}
      <header className="relative z-30 w-full max-w-2xl flex items-center justify-between px-2 pt-1 pb-4">
        {/* Mode Selector Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-white/80 backdrop-blur-md rounded-full border border-rose-300 shadow-sm text-xs font-black">
          <button
            onClick={() => setMode('dlc')}
            className={`px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer ${
              mode === 'dlc'
                ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-sm'
                : 'text-rose-800 hover:bg-rose-100/60'
            }`}
          >
            🎮 DLC 2 Meses
          </button>
          <button
            onClick={() => setMode('proposal')}
            className={`px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer ${
              mode === 'proposal'
                ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-sm'
                : 'text-rose-800 hover:bg-rose-100/60'
            }`}
          >
            💍 Pedido
          </button>
        </div>

        {/* Audio Sound Toggle */}
        <SoundToggle />
      </header>

      {/* Main Screen Container */}
      <div className="relative z-10 w-full max-w-4xl my-auto flex flex-col items-center justify-center transition-all duration-500">
        {/* MODE 1: DLC 2 MESES JUNTOS */}
        {mode === 'dlc' && (
          <>
            {dlcScreen === 'dlc-welcome' && (
              <DlcWelcomeScreen onUnlock={handleDlcUnlock} />
            )}
            {dlcScreen === 'dlc-achievements' && (
              <AchievementsScreen onOpenDlc={handleOpenDlcAlbum} />
            )}
            {dlcScreen === 'dlc-album' && (
              <SecretAlbumScreen onComplete={handleAlbumComplete} />
            )}
            {dlcScreen === 'dlc-final' && (
              <DlcFinalScreen onRestart={handleDlcRestart} />
            )}
          </>
        )}

        {/* MODE 2: ORIGINAL PROPOSAL FLOW */}
        {mode === 'proposal' && (
          <>
            {proposalScreen === 'welcome' && (
              <WelcomeScreen onStart={handleProposalStart} />
            )}

            {(proposalScreen === 1 ||
              proposalScreen === 2 ||
              proposalScreen === 3 ||
              proposalScreen === 4) && (
              <QuestionScreen
                key={`question-screen-${proposalScreen}`}
                step={proposalScreen as StepType}
                onNext={handleProposalNext}
              />
            )}

            {proposalScreen === 'final' && (
              <FinalScreen onRestart={handleProposalRestart} />
            )}
          </>
        )}
      </div>

      {/* Footer credit branding */}
      <footer className="w-full text-center text-xs text-rose-800/60 font-semibold pointer-events-none z-10 pt-4 pb-2">
        Feito com ❤️ para Luana
      </footer>
    </main>
  );
}
